Jaroslaw Czerwinski, July 09, 2020. assignment no1. "Travel Experts"  Course: CPRG210 Web Application Development. 






*footer code to keep it at the bottom of the page found on stackoverflow
https://stackoverflow.com/questions/643879/css-to-make-html-page-footer-stay-at-bottom-of-the-page-with-a-minimum-height-b#:~:text=CSS%20to%20make%20HTML%20page%20footer%20stay%20at,of%20content%20%28instead%20of%20overlapping%20the%20content%29.%20

*Mark Twain quote found on:
https://snarkynomad.com/the-best-of-mark-twains-travel-quotes/

*background photo from:
https://picsum.photos/id/551/7102/4740.jpg?hmac=fGrzYtiOAnVkgOC_P2jvR5asa0LsKH_Zk_8sy_Wgkcs

*fonts imported from google fonts:
https://fonts.google.com/

*ligin form copied for stackoverflow:
https://stackoverflow.com/questions/52718440/simple-html-login-form